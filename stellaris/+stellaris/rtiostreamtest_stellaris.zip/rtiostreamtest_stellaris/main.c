/* Copyright 2012 The MathWorks, Inc. */
#include "rtiostreamtest.h"

int main(int argc, char **argv) {
    return rtiostreamtest(argc, argv);
}

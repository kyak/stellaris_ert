/* Copyright 2012 The MathWorks, Inc. */

#ifndef __RTIOSTREAMTEST_H__
#define __RTIOSTREAMTEST_H__

int rtiostreamtest(int argc, char *argv[]);

#endif
